#include "test.h"
#include "stdio.h"
#include "usbd_cdc_if.h"
#include "shell_port.h"
#include "usb_device.h"
#include "QR_Encode.h"
#include "OLED_I2C.h"
#include "usart.h"
#include "interrupt.h"
#include "RNG.h"
#include "my_zw101.h"

extern int interrupt_full;
extern uint8_t rx_usart2_txt[17];
extern unsigned char re_date_2;
extern uint8_t re_pointer_2;
extern int x,time_count;
uint8_t test_1_count,test_2_count,test_3_count;
extern int recv_buf_count;
extern struct keys key[8];
unsigned char time_60s[2]={'6','0'};
extern char buff[5];
extern uint16_t count_1s;
uint16_t judge=0;
unsigned char keysword[7]={'*','*','*','*','*','*','\0'};
//unsigned char keysword[6]={'*','*','*','*','*','*'};

char QR_code[]="https://www.csdn.net/";
SHELL_EXPORT_VAR(SHELL_CMD_PERMISSION(0)|SHELL_CMD_TYPE(SHELL_TYPE_VAR_STRING), QR_code, QR_code, QR_code);
void app()
{
	key_read_2();
	if(test_1_count==1)
	{
		led();
	}
	if(test_2_count==1)
	{
		xungeng();
	}
	if(test_3_count==1)
	{
		QR();
	}
}

void QR()
{
	CREATE_QR_1(QR_code,2);
}

void xungeng()
{
	switch(judge)
	{
		case 0:
			QR_Update();
			break;
		case 1:
			Fingerprint_recognition(keysword[5]);
			break;
		case 2:
			send_data();
			break;
		
	}

}

void chawucihao()
{
	OLED_CLS();
	OLED_ShowCN(32,3,37);
	OLED_ShowCN(48,3,38);
	OLED_ShowCN(64,3,39);
	OLED_ShowCN(80,3,40);
	memset(keysword,'*',6);
}

void send_data()
{
	OLED_CLS();
	OLED_ShowCN(16,3,29);
	OLED_ShowCN(32,3,30);
	OLED_ShowCN(48,3,31);
	OLED_ShowCN(64,3,32);
	OLED_ShowCN(80,3,33);
	OLED_ShowCN(96,3,34);
	printf("Patrol point 1\r\n");
	printf("Check-in staff ID : %c\r\n",keysword[5]);
	HAL_Delay(1000);
	OLED_CLS();
	judge=0;
	memset(keysword,'*',6);
	memset(rx_usart2_txt,0,17);
}

/*

key[2].key_star=HAL_GPIO_ReadPin(GPIOG,GPIO_PIN_13);
key[3].key_star=HAL_GPIO_ReadPin(GPIOG,GPIO_PIN_14);
key[4].key_star=HAL_GPIO_ReadPin(GPIOG,GPIO_PIN_15);
key[5].key_star=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_3);
key[6].key_star=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_4);
key[7].key_star=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_5);
PG14 A 
PG13 B 
PB3	 C 
PG15 D 
PB5  E 
PB4  F 
*/
uint16_t count_update,full_count;
void QR_Update()
{
	uint16_t num=0,i;
	
		if(time_60s[0]=='0'&&time_60s[1]=='0')
		{
			password();
			time_60s[0]='6';
		}
		if(count_1s==1)
		{
			if(time_60s[1]=='/')
			{
				time_60s[0]--;
				time_60s[1]='9';
			}
			OLED_ShowStr(1,0,time_60s,1);
			time_60s[1]--;
			
			
			
			key_read_6();
			
			
			if(full_count==7)
			{
				for(i=0;i<=5;i++)
				{
					if(keysword[i]==buff[i])
					{
						num++;
					}
				}
				if(num!=5)
				{
					OLED_CLS();
					OLED_show_keyword_error();
					HAL_Delay(200);
					memset(keysword,'*',6);
					full_count=0;
				}
				else
				{
					OLED_CLS();
					OLED_show_keyword_OK();
					HAL_Delay(200);
					judge=1;
					num=0;
					full_count=0;
				}
			}
			
			if(num==6&&judge==0)
			{
				judge=1;
			}

			OLED_ShowStr(32,1,keysword,1);
			
			CREATE_QR(buff,2);

		
		}
}
void OLED_show_keyword_error()
{ //错误
	OLED_CLS();
	OLED_ShowCN(16,2,27);
	OLED_ShowCN(32,2,28);
	
	OLED_ShowCN(48,2,27);
	OLED_ShowCN(64,2,28);
	
	OLED_ShowCN(80,2,23);
	OLED_ShowCN(96,2,24);
}
void OLED_show_keyword_OK()
{	//正确
	OLED_CLS();
	OLED_ShowCN(16,2,27);
	OLED_ShowCN(32,2,28);
	
	OLED_ShowCN(48,2,27);
	OLED_ShowCN(64,2,28);
	
	OLED_ShowCN(80,2,11);
	OLED_ShowCN(96,2,12);
}

void Fingerprint_recognition(char code)
{
	
	switch(code)
	{
		case 'A':
			read_Fingerprint(1);
			break;
		case 'B':
			read_Fingerprint(2);
			break;
		case 'C':
			read_Fingerprint(3);
			break;
		default:
			judge=0;
			chawucihao();
			HAL_Delay(1000);
	}
}

void password()
{
	uint16_t i;
	for(i=0;i<=5;i++)
	{
		buff[i]=(random_range(0,4)+'A');
	}

	
	test_3_count=0;
}

void led()
{
	if(time_count%2==1)
	{
		HAL_GPIO_WritePin(GPIOG,GPIO_PIN_7,GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOG,GPIO_PIN_6,GPIO_PIN_SET);
	}
	else
	{
		HAL_GPIO_WritePin(GPIOG,GPIO_PIN_7,GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOG,GPIO_PIN_6,GPIO_PIN_RESET);
	}
}

/*

key[2].key_star=HAL_GPIO_ReadPin(GPIOG,GPIO_PIN_13);
key[3].key_star=HAL_GPIO_ReadPin(GPIOG,GPIO_PIN_14);
key[4].key_star=HAL_GPIO_ReadPin(GPIOG,GPIO_PIN_15);
key[5].key_star=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_3);
key[6].key_star=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_4);
key[7].key_star=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_5);
PG14 A 
PG13 B 
PB3	 C 
PG15 D 
PB5  E 
PB4  F 
*/
void key_read_2()
{
	
/*
	按键按下可回传键盘键值
*/
	if(key[0].sing_str==1)
	{
		recv_buf_count=1;
		key[0].sing_str=0;
	}
	if(key[1].sing_str==1)
	{
		recv_buf_count=0;
		key[1].sing_str=0;
	}
	

}

void key_read_6()
{
	uint16_t i;
	
	if(full_count!=6&&full_count!=7)
	{
		for(i=0;i<=6;i++)
		{
			if(keysword[i]=='*')
			{
				if(key[2].sing_str==1)
				{
					keysword[i]='B';
					key[2].sing_str=0;
//					 'B';
				}
				if(key[3].sing_str==1)
				{
					keysword[i]='A';
					key[3].sing_str=0;
//					'A';
					
				}
				if(key[4].sing_str==1)
				{
					keysword[i]='D';
					key[4].sing_str=0;
//					'D';
					
				}
				if(key[5].sing_str==1)
				{
					keysword[i]='C';
					key[5].sing_str=0;
//					'C';
					
				}
				if(key[6].sing_str==1)
				{
					keysword[i]='F';
					key[6].sing_str=0;
//					'F';
					
				}
				if(key[7].sing_str==1)
				{
					keysword[i]='E';
					key[7].sing_str=0;
//					'E';
				}
			}
		}
		full_count=0;
		for(i=0;i<=5;i++)
		{
			if(keysword[i]!='*')
			{
				full_count++;
			}
		}
	}
	
	
	if(full_count==6)
	{
		if(key[6].sing_str==1)
		{
			full_count=7;
			key[6].sing_str=0;
//			'F';
		}
	}
}
extern uint8_t OLED_GRAM[128][8];
char test1()
{
	OLED_CLS();
	test_1_count=1;
	return test_1_count;
}

SHELL_EXPORT_CMD(SHELL_CMD_PERMISSION(0)|SHELL_CMD_TYPE(SHELL_TYPE_CMD_FUNC), test1, test1, test1);

char test2()
{
	OLED_CLS();
	test_2_count=1;
	return test_2_count;
}
SHELL_EXPORT_CMD(SHELL_CMD_PERMISSION(0)|SHELL_CMD_TYPE(SHELL_TYPE_CMD_FUNC), test2, test2, test2);
//命令行任务模板


char test3()
{
	OLED_CLS();
	test_3_count=1;
	return test_3_count;
}
SHELL_EXPORT_CMD(SHELL_CMD_PERMISSION(0)|SHELL_CMD_TYPE(SHELL_TYPE_CMD_MAIN), test3, test3, test3);

int kill()
{
	interrupt_full = 0;
	printf("\r\n");
	if(test_1_count==1)
	{
		test_1_count=0;
		printf("Mission_1 complete\r\n");
	}
	if(test_2_count==1)
	{
		test_2_count=0;
		printf("Mission_2 complete\r\n");
	}
	if(test_3_count==1)
	{
		test_3_count=0;
		printf("Mission_3 complete\r\n");
	}
	memset(OLED_GRAM,0,128*8);
	printf("all kill\r\n");
	OLED_CLS();
	return 0;
}
SHELL_EXPORT_KEY(SHELL_CMD_PERMISSION(0), 0x03000000, kill, kill);
//按键任务模板

char str[] = "test string";
SHELL_EXPORT_VAR(SHELL_CMD_PERMISSION(0)|SHELL_CMD_TYPE(SHELL_TYPE_VAR_STRING), str, str, test);
//变量查询模板

//{0X01, 0XFF, 0XFF, 0XFF ,0XFF, 0X07,0X00,0X08, 0X00 ,0X05, 0X00 ,0X01 ,0X03 ,0XE8 ,0X01 ,0X00};
//这是指纹模块识别到正确指纹后返回的数组,可以通过该数组来确定指纹是否匹配



//EF 01 FF FF FF FF 07 00 08 00 05 00 01 06 82 00 9D 食指验证成功的数据包
//Serial_TxPacket[12]是检测目标值
uint8_t Serial_TxPacket[17]={0XEF ,0X01, 0XFF, 0XFF, 0XFF ,0XFF, 0X01,0X00,0X08, 0X32 ,0X01, 0X00 ,0X01 ,0X00 ,0X05 ,0X00 ,0X42};
unsigned char check_count[]={'3'};

extern uint16_t rx_count_ok;

uint16_t read_Fingerprint(uint16_t i)
{
	switch(i)
	{
		case 1:
			if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0) == 1)	//检测指纹模式是否与手指接触						
			{
				Serial_TxPacket[12]=0x00;
				Serial_TxPacket[16]=0x41;
				Serial_SendPacket();	//发送固定的十六进制数组，让指文模块判断传感器上的指纹是否与指纹库里的匹配

				if(rx_usart2_txt[9]==0X00&&rx_usart2_txt[0]==0XEF)//判断返回16进制数据的第9位：因为如果指纹匹配的话返回的数组的9位一定等于0X00;
				{
					check_count[0]='3';
					OLED_show_3();
					judge=2;
					memset(rx_usart2_txt,0,16);
					rx_count_ok=0;
				}
				else//否则就是指纹不匹配
				{
					OLED_show_2();
					check_count[0]--;
					rx_count_ok=0;
				}
			}
			else
			{
				OLED_show_1();
			}
					
			
			
			break;
		case 2:
			if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0) == 1)	//检测指纹模式是否与手指接触						
			{
				Serial_TxPacket[12]=0x01;
				Serial_TxPacket[16]=0x42;
				Serial_SendPacket();	//发送固定的十六进制数组，让指文模块判断传感器上的指纹是否与指纹库里的匹配
				
				if(rx_usart2_txt[9]==0X00&&rx_usart2_txt[0]==0XEF)//判断返回16进制数据的第9位：因为如果指纹匹配的话返回的数组的9位一定等于0X00;
				{
					check_count[0]='3';
					OLED_show_3();
					judge=2;
					memset(rx_usart2_txt,0,16);
					rx_count_ok=0;
				}
				else//否则就是指纹不匹配
				{
					OLED_show_2();
					check_count[0]--;
					rx_count_ok=0;
				} 

			}
			else
			{
				OLED_show_1();
			}
			break;
		case 3:
			if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0) == 1)	//检测指纹模式是否与手指接触						
			{
				Serial_TxPacket[12]=0x02;
				Serial_TxPacket[16]=0x43;
				Serial_SendPacket();	//发送固定的十六进制数组，让指文模块判断传感器上的指纹是否与指纹库里的匹配
					if(rx_usart2_txt[9]==0X00&&rx_usart2_txt[0]==0XEF)//判断返回16进制数据的第9位：因为如果指纹匹配的话返回的数组的9位一定等于0X00;
					{
						check_count[0]='3';
						OLED_show_3();
						judge=2;
						memset(rx_usart2_txt,0,16);
						rx_count_ok=0;
					}
					else//否则就是指纹不匹配
					{
						OLED_show_2();
						check_count[0]--;
						rx_count_ok=0;
					} 
				}
			else
			{
				OLED_show_1();
			}
			break;
	}
	if(check_count[0]=='0')
	{
		judge=0;
		check_count[0]='3';
		
	}
	OLED_ShowStr(8,6,check_count,2);
	return 0;
}



void Serial_SendPacket()
{
	
	Serial_SendArray(Serial_TxPacket, 17);
	//Serial_SendByte(0xFE);
}

void Serial_SendArray(uint8_t *Array, uint16_t Length)
{
	HAL_UART_Transmit_IT(&huart2,Array,Length);
//	Serial_SendByte(Serial_TxPacket[i]);		//依次调用Serial_SendByte发送每个字节数据

}
void Serial_SendByte(uint8_t Byte)
{
	HAL_UART_Transmit_IT(&huart2,&Byte,1);
	/*下次写入数据寄存器会自动清除发送完成标志位，故此循环后，无需清除标志位*/
}


void OLED_show_1()
{

	//请刷指纹
	OLED_ShowCN(24,0,17);
	OLED_ShowCN(40,0,18);
	OLED_ShowCN(56,0,19);
	OLED_ShowCN(72,0,20);
}

void OLED_show_2()
{
	OLED_CLS();
	//匹配错误
	OLED_ShowCN(24,2,21);
	OLED_ShowCN(40,2,22);
	OLED_ShowCN(56,2,23);
	OLED_ShowCN(72,2,24);
}

void OLED_show_3()
{
	OLED_CLS();
	//匹配成功
	OLED_ShowCN(24,2,21);
	OLED_ShowCN(40,2,22);
	OLED_ShowCN(56,2,11);
	OLED_ShowCN(72,2,12);
}
