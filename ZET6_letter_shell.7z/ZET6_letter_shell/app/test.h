#ifndef  __TEST_H_
#define  __TEST_H_

#include "main.h"
#include "shell.h"
void app(void);

char test1(void);
char test2(void);
char test3(void);

void password(void);
int kill(void);

uint16_t read_Fingerprint(uint16_t i);

void led(void);
void key_read_2(void);
void key_read_6(void);
void QR(void);

void xungeng(void);
void QR_Update(void);
void Fingerprint_recognition(char code);

void Serial_SendPacket(void);
void Serial_SendArray(uint8_t *Array, uint16_t Length);
void Serial_SendByte(uint8_t Byte);
void send_data(void);

void OLED_show_1(void);
void OLED_show_2(void);
void OLED_show_3(void);
void OLED_show_keyword_error(void);
void OLED_show_keyword_OK(void);
void chawucihao(void);
#endif
