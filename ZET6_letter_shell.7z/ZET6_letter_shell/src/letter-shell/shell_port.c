/**
 * @brief	shell???STM32L431??????
 * @author	mculover666
 * @date	2020/03/27 
*/

#include "shell.h"
#include "usart.h"
#include "shell_port.h"


Shell shell;
char shell_buffer[512];


signed short User_Shell_Write(char *data, unsigned short len)
{
    HAL_UART_Transmit(&huart1, (uint8_t *)data, (uint16_t)len, 1000);
    return len;
 
}

void User_Shell_Init(void)
{
    shell.write = User_Shell_Write;
    shellInit(&shell, shell_buffer, 512);
}
