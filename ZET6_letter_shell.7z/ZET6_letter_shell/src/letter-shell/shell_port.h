#ifndef _SHELL_PORT_H_
#define	_SHELL_PORT_H_

#include "shell.h"

extern Shell shell;

void User_Shell_Init(void);

#endif /* _SHELL_PORT_H_ */
