#ifndef _RNG__H_
#define _RNG__H_
#include "main.h"          

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
 
int random_range(int min, int max);
 
#endif
