#include "interrupt.h"
#include "usart.h"
#include "shell_port.h"
#include "usb_device.h"
#include "QR_Encode.h"
#include "OLED_I2C.h"
#include "my_zw101.h"

char judge_state[4]={0},double_click_time[4]={0},key_state[4]={0},double_click_timerEN[4]={0},
							single_key_flag[4]={100},double_key_flag[4]={0},long_key_flag[4]={0};
int key_time[4]={0};

struct keys key[8]={0,0,0,0};




extern uint8_t recv_buf;
int interrupt_full=0;
int x=0,time_count=0;

int recv_buf_count=0;
uint16_t count_1s;

SHELL_EXPORT_VAR(SHELL_CMD_PERMISSION(0)|SHELL_CMD_TYPE(SHELL_TYPE_VAR_INT), recv_buf_count, &recv_buf_count, test);
SHELL_EXPORT_VAR(SHELL_CMD_PERMISSION(0)|SHELL_CMD_TYPE(SHELL_TYPE_VAR_INT), interrupt_full, &interrupt_full, test);
SHELL_EXPORT_VAR(SHELL_CMD_PERMISSION(0)|SHELL_CMD_TYPE(SHELL_TYPE_VAR_INT), x, &x, test);
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)//�ص�����
{
	if(htim->Instance==TIM3)//��ʱ��3���¼�
	{
		x++;
		if(x==100)
		{
			time_count++;
			
			x=0;
		}
		if((time_count%2)==1&&count_1s==0)
		{
			count_1s=1;
		}

//				CDC_Transmit_FS("hello", 5); 

		key[0].key_star=HAL_GPIO_ReadPin(GPIOE,GPIO_PIN_3);
		key[1].key_star=HAL_GPIO_ReadPin(GPIOE,GPIO_PIN_4);
		
		key[2].key_star=HAL_GPIO_ReadPin(GPIOG,GPIO_PIN_13);
		key[3].key_star=HAL_GPIO_ReadPin(GPIOG,GPIO_PIN_14);
		key[4].key_star=HAL_GPIO_ReadPin(GPIOG,GPIO_PIN_15);
		key[5].key_star=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_3);
		key[6].key_star=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_4);
		key[7].key_star=HAL_GPIO_ReadPin(GPIOB,GPIO_PIN_5);

		
		
	for(int i=0;i<8;i++)
	{
		switch(key[i].judge_str)
		{
			case 0:
			{
				if(key[i].key_star==0)
				{
				key[i].judge_str=1;
				key[i].key_time=0;
				}
			}break;
			case 1:
			{
				if(key[i].key_star==0)
				{
				key[i].judge_str=2;
				}
				else
				{
					key[i].judge_str=0;
				}
			}break;
			case 2:
			{
				if(key[i].key_star==1)
				{
					if(key[i].key_time<70)key[i].sing_str=1;
					key[i].judge_str=0;
				}
				else
				{
					if(key[i].key_time>=70)
					{
						key[i].long_str=1;
					if(key[i].key_time>70)key[i].key_time=70;
					}
					key[i].key_time++;
				}
			}break;
		}	
	}
}
		

}


void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
   
    if(huart ->Instance == USART1)
    {
			if(recv_buf_count==1)
			{
				printf("recv:%#x\r\n",recv_buf);
			}
			shellHandler(&shell, recv_buf);
			HAL_UART_Receive_IT(&huart1, (uint8_t*)&recv_buf, 1);
    }

}

uint8_t rx_usart2_txt[17];
unsigned char re_date_2=0;
uint8_t re_pointer_2;
uint16_t BUF_SIZE=17;

uint16_t rx_count_ok=0;
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
    if (huart->Instance == USART2)
    {
			HAL_UARTEx_ReceiveToIdle_DMA(&huart2, rx_usart2_txt, BUF_SIZE);
			__HAL_DMA_DISABLE_IT(&hdma_usart2_rx, DMA_IT_HT);
				rx_count_ok=1;
//       memset(rx_usart2_txt, 0, re_date_2);
    }
}


/* ���ڴ���ص����� */


void HAL_UART_ErrorCallback(UART_HandleTypeDef * huart)
{
   if(huart->Instance == USART2)
   {
   	HAL_UARTEx_ReceiveToIdle_DMA(&huart2, rx_usart2_txt, BUF_SIZE); //�ֶ���������DMAģʽ��������
   	__HAL_DMA_DISABLE_IT(&hdma_usart2_rx, DMA_IT_HT);		   // �ֶ��ر�DMA_IT_HT�ж�
   	memset(rx_usart2_txt, 0, BUF_SIZE);							   // ������ջ���
		 
   }
}



